import {React} from 'react' ; 
import { withRouter ,useLocation, useHistory} from 'react-router-dom';

export const addSongs = () =>{ 
    return (
        <div className ="row">
        <h1>Add a Song</h1>
        </div>
    );
}
import {React} from 'react' ; 

export const deleteSongs = () =>{
    return (
        <h1>Delete a Song</h1>
        
    );
}
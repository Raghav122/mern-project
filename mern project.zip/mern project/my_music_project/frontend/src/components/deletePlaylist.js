import {React} from 'react' ; 
import { withRouter ,useLocation, useHistory} from 'react-router-dom';

export const deletePlaylist = () =>{ 
    return (
        <div className ="row">
        <h1>Delete a PlayList</h1>
        </div>
    );
}